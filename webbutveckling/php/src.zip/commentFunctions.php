<?php
	/* Funktioner (inklusive parametrar) som beh�vs f�r att administrera kommentarer */
    function listComments($inDBConnection){}
    function deleteComment($inDBConnection, $inCommentId) {}