<?php
	/* Funktioner (inklusive parametrar) som beh�vs f�r att administrera en artister */
    function printArtistForm() {}
    function listArtists($dbConnection) {}
    function updateArtist($dbConnection, $inArtistId, $inArtist) {}
    function deleteArtist($dbConnection, $inArtistId) {}
    function insertArtist($dbConnection, $inArtist) {}