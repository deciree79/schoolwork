<?php
	/* Funktioner (inklusive parametrar) som beh�vs f�r att administrera en s�ng */
    function printSongForm() {}
    function listSongs($inDBConnection) {}
    function updateSong($inDBConnection, $inSongId, $inArtistId, $inCount, $inTitle) {}
    function deleteSong($inDBConnection, $inSongId) {}
    function insertSong($inDBConnection, $inArtistId, $inCount, $inTitle) {}
