<?php
	/* Funktioner (inklusive parametrar) som beh�vs f�r att hantera anv�ndare och sessioner */
    function validateUser($inDBConnection, $inUserName, $inPassWord) {}
    function startSession() {}
    function endSession() {}
    function checkSession() {}
